/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appointmentsapp;

/**
 *
 * @author Cristy
 */
public class AppointmentsApp {
    public Appointment[] myAppointments;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      

        
        /**
        * Create a menu loop as follows:
        * 
        * How many appointments do you wish to make? 3

            Please make a selection:
            1. One Time Appointment
            2. Daily Appointment 
            3. Monthly Appointment 
            * 
            * 
            * For Each option, request the appropriate data from the user, and then 
            * instantiate the appropriate class/subclass in the Appointment hierarchy
            * 
        * Once the menu LOOP is over, ask the user the following question in a Do-While LOOP:
            * What is the date you wish to look up in your Appointments' Calendar? 
                    Enter the month: 03
                    Enter the day: 15
                    Enter the year: 2017
                
                * (Display the result in the following format:)   
                * 
                * On 3 / 15 / 2017 you have the following appointments: 
                    Dentist appointment with Dr. Smith at 13:30
                    Piano Lessons with Ms. Katie at 17:30
                    Athletic Training with Ms. Jones at 10:00

                Do you wish to look up another date? 
                   (If they answer NO, exit the program with message)
                  “Thank  you for using your appointment calendar.”

                    (If they answer YES, continue to ask for another date to look up).
                   "What is the date you wish to look up in your Appointments' Calendar? "
                        etc.,.


        */
        
        
        
    }
    
}
